# Integración recomendada para MartzFavela.com

Hello Elementor es un tema de WordPress; la landing sería una plantilla de página que funciona sobre ese tema. No hace falta sustituir tu WordPress ni perder el blog.

## Opciones

| Ruta | Qué permite | Implicación |
|---|---|---|
| Elementor Canvas + HTML adaptado | Incorporar rápidamente la landing dentro de WordPress | El contenido del bloque se edita como código, no como widgets individuales. |
| Plantilla híbrida de Elementor — recomendada | Editar textos, imágenes, botones y secciones visualmente; conservar efectos mediante CSS/JS específico | Requiere reconstruir la estructura con contenedores y widgets, después validar en tu instalación. |
| Plantilla de página programada en un tema hijo | Mantener el HTML y el comportamiento con gran fidelidad y control | Su edición dependerá de código o de campos configurados; no será una plantilla visual de Elementor. |

## Propuesta concreta

1. Crear una página de prueba en un entorno de staging, manteniendo la portada actual.
2. Usar Hello Elementor y disposición Elementor Canvas, dado que la landing tiene su propia navegación y pie. Canvas elimina la cabecera, pie y barras laterales del tema.
3. Reconstruir hero, servicios, metodología, formación, trayectoria y contacto con contenedores y widgets nativos.
4. Registrar colores y tipografías globales. Conservar originales de los logos y subir la fotografía a Medios.
5. Mantener ondas SVG, tarjetas con profundidad y órbitas en componentes de código acotados. Adaptar selectores al DOM de Elementor y al ciclo de inicialización del editor.
6. Acotar CSS y JavaScript a esta landing; no copiar sin adaptación reglas globales como body, header, .container o todos los enlaces. Cargar recursos solo donde corresponda mediante un pequeño plugin propio o tema hijo, sin modificar el tema padre.
7. Reproducir los casos mediante componentes propios accesibles o las ventanas emergentes de Elementor Pro si la licencia instalada lo permite. Comprobar teclado, cierre, foco y móvil.
8. Preparar las páginas de idioma en WordPress y conectar el selector a sus URLs. Definir español en la raíz y versiones /en/ y /fr/, canonical propio por versión y hreflang recíproco.
9. Validar diseño, traducciones, enlaces, caché y rendimiento en la instalación real; después exportar la plantilla JSON o el kit correspondiente. Los recursos personalizados deben acompañar al export.
10. Solo al aprobar la publicación, retirar noindex y asignar la página como portada. Mantener entradas, blog y panel de WordPress.

El HTML adjunto es un prototipo funcional: aún no es un JSON importable de Elementor. Renombrar un HTML a .json no lo convierte en una plantilla. Un JSON con un único widget HTML tampoco equivale a una reconstrucción nativa editable.

## Integración rápida del HTML

Para una revisión en WordPress se puede usar Canvas y un widget HTML adaptado, separando la estructura del body de los recursos CSS/JS. No pegar el documento completo con html/head/body dentro de un widget, ni incrustar la página mediante iframe como solución definitiva. El sitio ya incluye navegación y pie: evita duplicarlos con el tema.

El archivo index.html no debe colocarse sin planificación en la raíz del WordPress: podría competir con index.php según la configuración del servidor. La ruta de pruebas o una plantilla de página evita alterar la portada actual.

## Idiomas y SEO

El selector del prototipo cambia texto localmente para facilitar la revisión offline. Para publicación, servir contenido completo por URL de idioma ayuda a que cada versión se descubra e indexe. Los archivos estáticos por idioma incluidos ofrecen la base de contenidos, pero aún deben integrarse con la estructura de WordPress.

Antes de publicar: revisar traducciones, definir títulos y descripciones por idioma, canonical, hreflang, sitemap, imagen social, noindex y rendimiento real. El blog puede seguir en WordPress con su flujo editorial; la landing no exige migrarlo.

## Referencias oficiales consultadas

- Hello Elementor: https://elementor.com/help/what-is-elementor-hello-theme/
- Canvas: https://elementor.com/help/using-elementors-canvas-page-template/
- Widget HTML: https://elementor.com/help/html-widget/
- Plantillas e importación: https://elementor.com/help/template-library/
- SEO multilingüe: https://developers.google.com/search/docs/specialty/international/managing-multi-regional-sites
